//
// File: resampling_types.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

#ifndef RESAMPLING_TYPES_H
#define RESAMPLING_TYPES_H

// Include Files
#include "rtwtypes.h"

#endif
//
// File trailer for resampling_types.h
//
// [EOF]
//
