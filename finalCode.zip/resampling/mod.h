//
// File: mod.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

#ifndef MOD_H
#define MOD_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
double b_mod(double x, double y);

}

#endif
//
// File trailer for mod.h
//
// [EOF]
//
