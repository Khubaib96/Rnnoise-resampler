//
// File: ipermute.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

#ifndef IPERMUTE_H
#define IPERMUTE_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void ipermute(const ::coder::array<double, 1U> &b,
              ::coder::array<double, 1U> &a);

}

#endif
//
// File trailer for ipermute.h
//
// [EOF]
//
