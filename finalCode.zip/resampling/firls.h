//
// File: firls.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

#ifndef FIRLS_H
#define FIRLS_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void firls(double varargin_1, const double varargin_2[4],
           ::coder::array<double, 2U> &h);

}

#endif
//
// File trailer for firls.h
//
// [EOF]
//
