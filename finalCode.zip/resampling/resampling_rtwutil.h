//
// File: resampling_rtwutil.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

#ifndef RESAMPLING_RTWUTIL_H
#define RESAMPLING_RTWUTIL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern double rt_hypotd_snf(double u0, double u1);

#endif
//
// File trailer for resampling_rtwutil.h
//
// [EOF]
//
