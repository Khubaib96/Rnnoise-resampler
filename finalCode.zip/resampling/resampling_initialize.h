//
// File: resampling_initialize.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

#ifndef RESAMPLING_INITIALIZE_H
#define RESAMPLING_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void resampling_initialize();

#endif
//
// File trailer for resampling_initialize.h
//
// [EOF]
//
