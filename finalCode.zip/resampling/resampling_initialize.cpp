//
// File: resampling_initialize.cpp
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

// Include Files
#include "resampling_initialize.h"
#include "rt_nonfinite.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void resampling_initialize()
{
}

//
// File trailer for resampling_initialize.cpp
//
// [EOF]
//
