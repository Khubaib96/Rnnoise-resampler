//
// File: resampling_terminate.cpp
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

// Include Files
#include "resampling_terminate.h"
#include "rt_nonfinite.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void resampling_terminate()
{
}

//
// File trailer for resampling_terminate.cpp
//
// [EOF]
//
