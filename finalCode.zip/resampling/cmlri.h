//
// File: cmlri.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

#ifndef CMLRI_H
#define CMLRI_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
int cmlri(const creal_T z, creal_T *y);

}

#endif
//
// File trailer for cmlri.h
//
// [EOF]
//
