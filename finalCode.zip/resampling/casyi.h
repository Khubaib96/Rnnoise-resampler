//
// File: casyi.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 29-Mar-2023 00:10:34
//

#ifndef CASYI_H
#define CASYI_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
int casyi(const creal_T z, creal_T *y);

}

#endif
//
// File trailer for casyi.h
//
// [EOF]
//
